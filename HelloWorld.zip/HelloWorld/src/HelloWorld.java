public class HelloWorld {

    public static void main(String[] args) {
        System.out.println("Hello World");

        int myFirstNumber = (10 + 5) + (2 * 10);
        int mySecondNumber = 12;
        int myThirdNumber = myFirstNumber * 2;
        int myFourthNumber = myFirstNumber + mySecondNumber + myThirdNumber;
        System.out.println(myFourthNumber);
        int myLastOne = 1000 - myFourthNumber;
        System.out.println(myLastOne);
    }
}
